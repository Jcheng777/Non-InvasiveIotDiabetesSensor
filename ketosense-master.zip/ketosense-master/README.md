ketosense
=========

An Arduino ketosis detector.

This is the source-code for an Arduino controlled breath acetone detector. The purpouse for the instrument is to detect
if a person is in a metabilic state called ketosis. The instrument uses an electrochemical gas sensor called TGS822.
A digital temperatur and humidity sensor called DHT11. A 2x16 char LCD display and is powered by an Arduino Uno board.

A more detailed description can be found at http://jenslabs.com/category/electronics/ketosis-detector/
